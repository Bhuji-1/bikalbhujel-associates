// To publish a document, put the file in /public/documents and add an entry below.
// Example: { title: 'Budget 2082/83 Highlights', category: 'Tax Updates', date: '2026-05-29', file: '/documents/budget-2082-83.pdf' }
export type DocumentItem = {
  title: string
  category: string
  date: string
  file: string
  description?: string
}

// To publish a photo, put the image in /public/gallery and add an entry below.
// Example: { src: '/gallery/tax-seminar.jpg', alt: 'Bikal Bhujel presenting at a VAT seminar', caption: 'VAT seminar, Kathmandu' }
export type GalleryItem = {
  src: string
  alt: string
  caption?: string
}

export const documents: DocumentItem[] = []

export const gallery: GalleryItem[] = []
