import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { Services } from '@/components/services'
import { Approach } from '@/components/approach'
import { Industries } from '@/components/industries'
import { Resources } from '@/components/resources'
import { Faq } from '@/components/faq'
import { Contact } from '@/components/contact'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <Services />
        <Approach />
        <Industries />
        <Resources />
        <Faq />
        <Contact />
      </main>
      <SiteFooter />
    </>
  )
}
