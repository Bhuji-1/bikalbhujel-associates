const industries = [
  'Hydropower & Energy',
  'Tourism & Hospitality',
  'Manufacturing & Trading',
  'IT & Startups',
  'NGOs & INGOs',
  'Cooperatives',
  'Healthcare & Education',
  'Individuals & Families',
]

const commitments = [
  {
    title: 'A clear compliance calendar',
    description:
      'Every IRD, OCR and VAT deadline for your business mapped out at the start of the year, with reminders well before each one.',
  },
  {
    title: 'Fixed fees agreed upfront',
    description:
      'You know the cost of the engagement before work begins. No surprise invoices at year-end.',
  },
  {
    title: 'Plain-language advice',
    description:
      'We explain what your numbers mean and what to do next, in Nepali or English, without the jargon.',
  },
]

export function Industries() {
  return (
    <section id="industries" className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">Industries</p>
            <h2 className="mt-4 text-balance font-serif text-4xl tracking-tight md:text-5xl">
              Sector knowledge that saves you time and tax
            </h2>
            <ul className="mt-10 grid grid-cols-2 gap-x-6 gap-y-4">
              {industries.map((industry) => (
                <li
                  key={industry}
                  className="border-b border-primary-foreground/20 pb-3 text-primary-foreground/90"
                >
                  {industry}
                </li>
              ))}
            </ul>
          </div>

          <ul className="flex flex-col gap-6">
            {commitments.map((item) => (
              <li
                key={item.title}
                className="rounded-lg border border-primary-foreground/15 bg-primary-foreground/5 p-8"
              >
                <h3 className="font-serif text-2xl leading-snug tracking-tight">{item.title}</h3>
                <p className="mt-3 leading-relaxed text-primary-foreground/80">{item.description}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
