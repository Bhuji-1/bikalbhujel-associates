const steps = [
  {
    number: '01',
    title: 'Discovery call',
    description:
      'A free 30-minute conversation to understand your business, current obligations and what is keeping you up at night.',
  },
  {
    number: '02',
    title: 'Clear proposal',
    description:
      'A fixed-fee engagement letter with scope, deliverables and a compliance calendar. No surprise invoices.',
  },
  {
    number: '03',
    title: 'Onboarding',
    description:
      'We securely collect past records, connect to your accounting software and take over correspondence with authorities.',
  },
  {
    number: '04',
    title: 'Ongoing partnership',
    description:
      'A dedicated partner, quarterly reviews and proactive reminders so deadlines never catch you off guard.',
  },
]

export function Approach() {
  return (
    <section id="approach" className="mx-auto max-w-6xl px-6 py-24">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr]">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">Our approach</p>
          <h2 className="mt-4 text-balance font-serif text-4xl tracking-tight md:text-5xl">
            Partner-led, from the first call onwards
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            Every client works directly with a qualified chartered accountant, not a rotating cast
            of juniors. We are members of the Institute of Chartered Accountants and bound by its
            code of ethics.
          </p>
        </div>

        <ol className="divide-y divide-border border-y border-border">
          {steps.map((step) => (
            <li key={step.number} className="grid grid-cols-[3rem_1fr] gap-4 py-7">
              <span className="font-serif text-lg text-accent-foreground/60">{step.number}</span>
              <div>
                <h3 className="font-serif text-2xl tracking-tight">{step.title}</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{step.description}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
