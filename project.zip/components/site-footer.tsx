export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-10 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
        <div>
          <p className="font-serif text-lg text-foreground">Bikal Bhujel &amp; Associates</p>
          <p>Chartered Accountants &middot; Registered with ICAN &middot; Kathmandu, Nepal</p>
        </div>
        <p>&copy; {new Date().getFullYear()} Bikal Bhujel &amp; Associates. All rights reserved.</p>
      </div>
    </footer>
  )
}
