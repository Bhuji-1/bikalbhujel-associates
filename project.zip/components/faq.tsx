import { Plus } from 'lucide-react'

const faqs = [
  {
    q: 'How are your fees structured?',
    a: 'Most engagements are on a fixed monthly or annual fee agreed upfront in your engagement letter. One-off projects such as valuations or due diligence are quoted separately.',
  },
  {
    q: 'Do you work with clients remotely?',
    a: 'Absolutely. Many of our clients never visit the office. We use secure document portals, e-signatures and video calls for everything.',
  },
  {
    q: 'Which accounting software do you support?',
    a: 'We work with Tally, Swastik, QuickBooks, Xero and most IRD-approved billing software. If you are just starting out, we will recommend the right fit.',
  },
  {
    q: 'Can you help foreign investors set up a business in Nepal?',
    a: 'Yes. We handle company registration, FDI approval from the Department of Industry, foreign investment recording with Nepal Rastra Bank and the ongoing tax and audit compliance that follows.',
  },
  {
    q: 'Are you registered with ICAN?',
    a: 'Yes. Bikal Bhujel & Associates is a firm of Chartered Accountants registered with the Institute of Chartered Accountants of Nepal (ICAN) and follows its code of ethics and Nepal Financial Reporting Standards (NFRS).',
  },
]

export function Faq() {
  return (
    <section id="faq" className="mx-auto max-w-3xl px-6 py-24">
      <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">FAQ</p>
      <h2 className="mt-4 text-balance font-serif text-4xl tracking-tight md:text-5xl">
        Common questions
      </h2>
      <div className="mt-10 divide-y divide-border border-y border-border">
        {faqs.map((item) => (
          <details key={item.q} className="group py-5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-lg font-medium [&::-webkit-details-marker]:hidden">
              {item.q}
              <Plus
                className="size-5 shrink-0 text-muted-foreground transition-transform group-open:rotate-45"
                aria-hidden="true"
              />
            </summary>
            <p className="mt-3 leading-relaxed text-muted-foreground">{item.a}</p>
          </details>
        ))}
      </div>
    </section>
  )
}
