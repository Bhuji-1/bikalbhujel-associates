'use client'

import type { FormEvent } from 'react'
import { Clock, Mail, MapPin, Phone } from 'lucide-react'
import { Button } from '@/components/ui/button'

const FIRM_EMAIL = 'ca.bikalbhujel@gmail.com'

const inputClass =
  'mt-2 w-full rounded-md border border-input bg-background px-3 py-2.5 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/20'

export function Contact() {
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const subject = `Consultation request: ${data.get('service')}`
    const body = [
      `Name: ${data.get('name')}`,
      `Email: ${data.get('email')}`,
      `Phone: ${data.get('phone') || '—'}`,
      `Service: ${data.get('service')}`,
      '',
      `${data.get('message')}`,
    ].join('\n')
    window.location.href = `mailto:${FIRM_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  return (
    <section id="contact" className="border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-14 px-6 py-24 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">Contact</p>
          <h2 className="mt-4 text-balance font-serif text-4xl tracking-tight md:text-5xl">
            Book a free consultation
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            Tell us a little about your situation and a partner will get back to you within one
            business day.
          </p>

          <ul className="mt-10 flex flex-col gap-5">
            <li className="flex gap-4">
              <MapPin className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
              <span>
  Bhrikuti Tole, Banasthali
  <br />
  Kathmandu-16, Nepal
              </span>
            </li>
            <li className="flex gap-4">
              <Phone className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
              <a href="tel:+9779816652432" className="hover:underline">
                +977 9816652432
              </a>
            </li>
            <li className="flex gap-4">
              <Mail className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
              <a href={`mailto:${FIRM_EMAIL}`} className="hover:underline">
                {FIRM_EMAIL}
              </a>
            </li>
            <li className="flex gap-4">
              <Clock className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
              <span>Sun – Fri, 10:00am – 5:00pm</span>
            </li>
          </ul>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-lg border border-border bg-background p-6 sm:p-8"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="text-sm font-medium">
              Full name
              <input name="name" required autoComplete="name" className={inputClass} />
            </label>
            <label className="text-sm font-medium">
              Email
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                className={inputClass}
              />
            </label>
            <label className="text-sm font-medium">
              Phone <span className="font-normal text-muted-foreground">(optional)</span>
              <input name="phone" type="tel" autoComplete="tel" className={inputClass} />
            </label>
            <label className="text-sm font-medium">
              Service needed
              <select name="service" required defaultValue="" className={inputClass}>
                <option value="" disabled>
                  Select a service
                </option>
                <option>Audit & Assurance</option>
                <option>Direct Taxation</option>
                <option>VAT & Excise</option>
                <option>Accounting & Bookkeeping</option>
                <option>Company Formation & Compliance</option>
                <option>Business Advisory</option>
                <option>Something else</option>
              </select>
            </label>
            <label className="text-sm font-medium sm:col-span-2">
              How can we help?
              <textarea name="message" required rows={5} className={inputClass} />
            </label>
          </div>
          <Button type="submit" className="mt-6 h-11 w-full px-5 text-base sm:w-auto">
            Send enquiry
          </Button>
          <p className="mt-4 text-xs text-muted-foreground">
            Submitting opens your email app with your enquiry pre-filled. Everything you share is
            kept strictly confidential.
          </p>
        </form>
      </div>
    </section>
  )
}
