import Image from 'next/image'
import { Download, FileText, ImageIcon } from 'lucide-react'
import { documents, gallery } from '@/lib/resources'

function fileType(path: string) {
  return path.split('.').pop()?.toUpperCase() ?? 'FILE'
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
}

function EmptyState({ icon: Icon, message }: { icon: typeof FileText; message: string }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed border-border px-6 py-12 text-center">
      <Icon className="size-6 text-muted-foreground" aria-hidden="true" />
      <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">{message}</p>
    </div>
  )
}

export function Resources() {
  return (
    <section id="resources" className="border-t border-border bg-card">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">Resources</p>
        <h2 className="mt-4 max-w-2xl text-balance font-serif text-4xl tracking-tight md:text-5xl">
          Publications, updates and gallery
        </h2>
        <p className="mt-4 max-w-2xl leading-relaxed text-muted-foreground">
          Tax updates, circulars, checklists and moments from our work, shared for clients and the
          wider business community.
        </p>

        <div className="mt-12">
          <h3 className="font-serif text-2xl tracking-tight">Documents</h3>
          <div className="mt-6">
            {documents.length === 0 ? (
              <EmptyState
                icon={FileText}
                message="Documents such as tax updates, budget highlights and compliance checklists will be published here soon."
              />
            ) : (
              <ul className="divide-y divide-border border-y border-border">
                {documents.map((doc) => (
                  <li key={doc.file}>
                    <a
                      href={doc.file}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center gap-4 py-5 transition-colors hover:bg-secondary/50"
                    >
                      <span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-secondary text-xs font-semibold text-primary">
                        {fileType(doc.file)}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block font-medium text-foreground">{doc.title}</span>
                        <span className="mt-1 block text-sm text-muted-foreground">
                          {doc.category} · {formatDate(doc.date)}
                          {doc.description ? ` · ${doc.description}` : ''}
                        </span>
                      </span>
                      <Download
                        className="size-5 shrink-0 text-muted-foreground transition-colors group-hover:text-primary"
                        aria-hidden="true"
                      />
                      <span className="sr-only">(opens in a new tab)</span>
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="mt-16">
          <h3 className="font-serif text-2xl tracking-tight">Gallery</h3>
          <div className="mt-6">
            {gallery.length === 0 ? (
              <EmptyState
                icon={ImageIcon}
                message="Photos from our office, seminars and events will appear here soon."
              />
            ) : (
              <ul className="grid grid-cols-2 gap-4 md:grid-cols-3">
                {gallery.map((photo) => (
                  <li key={photo.src}>
                    <figure>
                      <div className="relative aspect-[4/3] overflow-hidden rounded-lg bg-secondary">
                        <Image
                          src={photo.src || '/placeholder.svg'}
                          alt={photo.alt}
                          fill
                          sizes="(min-width: 768px) 33vw, 50vw"
                          className="object-cover"
                        />
                      </div>
                      {photo.caption && (
                        <figcaption className="mt-2 text-sm text-muted-foreground">{photo.caption}</figcaption>
                      )}
                    </figure>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
