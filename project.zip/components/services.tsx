import {
  BookOpen,
  Building2,
  FileCheck2,
  FileSpreadsheet,
  Globe2,
  Landmark,
  LineChart,
  Receipt,
  Users,
} from 'lucide-react'

const services = [
  {
    icon: FileCheck2,
    title: 'Audit & Assurance',
    description:
      'Statutory, internal and tax audits carried out with rigour and independence, so stakeholders can rely on your financial statements.',
  },
  {
    icon: Landmark,
    title: 'Direct Taxation',
    description:
      'Income tax planning, PAN registration, TDS and annual returns, assessments and representation before the Inland Revenue Department.',
  },
  {
    icon: Receipt,
    title: 'VAT & Excise',
    description:
      'VAT registration, monthly returns, purchase and sales book reconciliation and excise advisory to keep your indirect tax position clean.',
  },
  {
    icon: BookOpen,
    title: 'Accounting & Bookkeeping',
    description:
      'Accurate, up-to-date books and management reports, prepared on the cloud software you already use.',
  },
  {
    icon: Building2,
    title: 'Company Formation & Compliance',
    description:
      'Company registration and annual filings with the Office of the Company Registrar (OCR), plus secretarial support under the Companies Act, 2063.',
  },
  {
    icon: FileSpreadsheet,
    title: 'NFRS Financial Reporting',
    description:
      'Preparation and review of financial statements under Nepal Financial Reporting Standards (NFRS) and NFRS for SMEs, including transition support.',
  },
  {
    icon: Users,
    title: 'Payroll & SSF Compliance',
    description:
      'Monthly payroll processing, salary TDS, Social Security Fund (SSF) contributions and labour law compliance for your staff.',
  },
  {
    icon: Globe2,
    title: 'Foreign Investment (FDI)',
    description:
      'FDI approvals from the Department of Industry, Nepal Rastra Bank recording, repatriation and ongoing compliance for foreign-owned entities.',
  },
  {
    icon: LineChart,
    title: 'Business Advisory',
    description:
      'Budgeting, cash-flow forecasting, valuations and due diligence to support fundraising and growth decisions.',
  },
]

export function Services() {
  return (
    <section id="services" className="border-t border-border bg-card">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="max-w-2xl">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">Services</p>
          <h2 className="mt-4 text-balance font-serif text-4xl tracking-tight md:text-5xl">
            Full-service accounting under one roof
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            From day-to-day bookkeeping to complex audits, a single partner-led team handles your
            finances end to end.
          </p>
        </div>

        <ul className="mt-14 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ icon: Icon, title, description }) => (
            <li key={title} className="flex flex-col bg-card p-8">
              <span className="flex size-11 items-center justify-center rounded-md bg-primary/10 text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className="mt-6 font-serif text-2xl tracking-tight">{title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">{description}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
