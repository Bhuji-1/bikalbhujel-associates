import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

const stats = [
  { value: 'ICAN', label: 'Registered practice' },
  { value: '1:1', label: 'Partner-led service' },
]

export function Hero() {
  return (
    <section id="top" className="mx-auto max-w-6xl px-6 pb-20 pt-16 md:pt-24">
      <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">
            Audit &middot; Tax &middot; Advisory
          </p>
          <h1 className="mt-5 text-balance font-serif text-5xl leading-[1.05] tracking-tight md:text-6xl">
            Numbers you can trust. Advice you can act on.
          </h1>
          <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Bikal Bhujel &amp; Associates is an independent chartered accountancy practice helping founders,
            family businesses and individuals stay compliant, file on time and make better
            financial decisions.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button className="h-11 px-5 text-base" render={<a href="#contact" />} nativeButton={false}>
              Book a free consultation
              <ArrowRight data-icon="inline-end" />
            </Button>
            <Button
              variant="outline"
              className="h-11 px-5 text-base"
              render={<a href="#services" />}
              nativeButton={false}
            >
              Explore services
            </Button>
          </div>

          <dl className="mt-14 grid max-w-sm grid-cols-2 gap-6 border-t border-border pt-8">
            {stats.map((stat) => (
              <div key={stat.label}>
                <dt className="sr-only">{stat.label}</dt>
                <dd className="font-serif text-3xl tracking-tight">{stat.value}</dd>
                <dd className="mt-1 text-sm text-muted-foreground">{stat.label}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative aspect-[4/5] overflow-hidden rounded-lg">
          <Image
            src="/images/office.png"
            alt="A quiet meeting room at the Bikal Bhujel & Associates office with financial documents on a walnut table"
            fill
            priority
            sizes="(min-width: 1024px) 480px, 100vw"
            className="object-cover"
          />
        </div>
      </div>
    </section>
  )
}
